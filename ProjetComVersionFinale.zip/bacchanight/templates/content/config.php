<?php 

$titre = "Bacchanight";
$description = "<h2 style=\"font-family: 'CaslonCP', cursive;\">Bacchanight</h2>
<hr>
<p>Après le succès de la première édition de la Bacchanight ! (mardi 26 avril 2016), le musée propose une Bacchanight 2, un événement par et pour les étudiants !</p>
<p>La Baccha-night, du mot « bacchanales » fêtes mythologiques en l’honneur du dieu du vin Bacchus,est une nocturne étudiante proposée par le musée des Beaux-Arts le mardi 21 mars 2017.</p>
<p>Bacchanight Une soirée culturelle et festive avec de nombreuses interventions tout au long de la soirée : médiation, performances, musique, installations, jeux, danse, débats…</p>
";
$email = "s.choux@mairie-bordeaux.fr";
$phone = "+33 5 56 10 20 56";
$street = "20 Cours d'Albret";
$zipcode = "33000";
$city = "Bordeaux";
$country = "France";
$date = "MARDI 21 MARS 2017";
$address = "<p>".$street."<br>".$zipcode." ".$city.", ".$country."</p>";
$heure = "20h - 00h";
$color1 = "#201C54";
$color2 = "#E72A7B";
$colorStyle = "<style>#footer {background: #201C54;}</style>     <style>#footer .copyrights {background: #E72A7B background: -webkit-linear-gradient(top, #201C54 0%, #E72A7B 50%); background: linear-gradient(to bottom, #201C54 0%, #E72A7B 50%); }</style>
";
$captcha = "6Le8yB4UAAAAABTVJGnHAyTuU7Ej7uwFPGKAF2pv";
$programme = "<?xml version='1.0' standalone='yes'?>
<ListeProgramme>
<programme>
<event>
<location>M</location>
<titre>20h15 : Défilé de mode</titre>
<description>Par les élèves de l’école de mode IBSM, coiffure et maquillage par les élèves de l’école Piger Création</description>
</event>
<event>
<location>G</location>
<titre>20h15 à 22h30: Visite et dégustation de vins</titre>
<description>Visites flash par l’association Artothem, suivie d’une dégustation de vins par Blandine Prevot, Geoffrey Thibaud, Jordi Payot et Adrien Ferraro</description>
</event>
<event>
<location>M</location>
<titre>20h30 et 22h : Histoire d'amour chantée</titre>
<description>Par Laura-Marie Bertinoucourt Leleu, Reine Boukaka Prefina et Ema Donnefort</description>
</event>
</programme>
<programme>
<event>
<location>M</location>
<titre>20h15 : Défilé de mode</titre>
<description>Par les élèves de l’école de mode IBSM, coiffure et maquillage par les élèves de l’école Piger Création</description>
</event>
<event>
<location>G</location>
<titre>20h15 à 22h30: Visite et dégustation de vins</titre>
<description>Visites flash par l’association Artothem, suivie d’une dégustation de vins par Blandine Prevot, Geoffrey Thibaud, Jordi Payot et Adrien Ferraro</description>
</event>
<event>
<location>M</location>
<titre>20h30 et 22h : Histoire d'amour chantée</titre>
<description>Par Laura-Marie Bertinoucourt Leleu, Reine Boukaka Prefina et Ema Donnefort</description>
</event>
</programme>
</ListeProgramme>";

?>