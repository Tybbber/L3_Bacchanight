	  <h2 style="font-family: 'CaslonCP', cursive;">Bacchanight</h2>
          <hr>
          <p>
            Après le succès de la première édition de la Bacchanight ! (mardi 26 avril 2016), le musée propose une <strong>Bacchanight 2</strong>, un événement par et pour les étudiants !
          </p>
          <p>
            La Baccha-night, du mot « bacchanales » fêtes mythologiques en l’honneur du dieu du vin Bacchus,est une nocturne étudiante proposée par le musée des Beaux-Arts le <strong>mardi 21 mars 2017</strong>.
          </p>
          <p>Bacchanight
            Une soirée culturelle et festive avec de nombreuses interventions tout au long de la soirée :
            médiation, performances, musique, installations, jeux, danse, débats…
          </p>
