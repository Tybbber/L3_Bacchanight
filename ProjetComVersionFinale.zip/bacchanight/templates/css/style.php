<?php
    header("Content-type: text/css; charset: UTF-8");
    include "../content/css.php";
  ?>

@font-face {
    font-family: CaslonCP;
    src: url(../fonts/CaslonCP.otf);
}

body, html {
	font-family: 'Raleway', sans-serif;
	text-rendering: optimizeLegibility !important;
	-webkit-font-smoothing: antialiased !important;
	color: #000;
	font-weight: 300;
	width: 100% !important;
	height: 100% !important;
	background: <?php echo $bgcolor; ?>;
}
.gray-img {
	-webkit-filter: grayscale(100%);
	 filter: grayscale(100%);
}
.gray-img:hover {
	-webkit-filter: grayscale(0%);
	 filter: grayscale(0%);
}
h2 {
	margin: 0 0 20px 0;
	font-weight: 500;
	font-size: 34px;
	color: #333;
	text-transform: uppercase;
}
h3 {
	font-size: 22px;
	font-weight: 500;
	color: #333;
}
h4 {
	font-size: 24px;
	text-transform: uppercase
	color: #333;
}
h5 {
	text-transform: uppercase;
	font-weight: 700;
	line-height: 20px;
}
p {
	font-size: 16px;
}
p.intro {
	margin: 12px 0 0;uppercase;
}
h3 {
	font-size: 22px;
	font-weight: 500;
	color: #333;
}
h4 {
	font-size: 24px;
	text-transform: uppercase
a {
	color: <?php echo $maincolor1; ?>;
}
a:hover, a:focus {
	text-decoration: none;
	color: #222;
}
ul, ol {
	list-style: none;
}
.clearfix:after {
	visibility: hidden;
	display: block;
	font-size: 0;
	content: " ";
	clear: both;
	height: 0;
}
.clearfix {
	display: inline-block;
}
* html .clearfix {
	height: 1%;
}
	padding: 0;
	webkit-padding: 0;
	moz-padding: 0;
}
hr {
	height: 2px;
	width: 70px;
	text-align: center;
	position: relative;
	/*background: <?php echo $maincolor1; ?>;*/
	background : white;
	margin: 0;
	margin-bottom: 40px;
	border: 0;
}
.btn:active, .btn.active {
	background-ima
	-webkit-box-shadow: none;
	box-shadow: none;
}
a:focus, .btn:focus, .btn:active:focus, .btn.active:focus, .btn.focus, .btn:active.focus, .btn.active.focus {
	outline: none;
	outline-offset: none;
}
/* Navigation */
#prg {
	padding: 20px;
	transition: all 0.8s;
}
#prg.navbar-default {
	background-color: rgba(0,0,0,.4);
	border-color: rgba(231, 231, 231, 0);
}
#prg a.navbar-brand {
	font-family: 'CaslonCP', cursive;
	text-transform: uppercase;
	font-size: 28px;
	color: #fff;
	font-weight: 400;
	letter-spacing: 1px;
}
#prg a.navbar-brand:hover {
	color: <?php echo $maincolor1; ?>;
}
#prg.navbar-default .navbar-nav > li > a {
	text-transform: uppercase;
	color: #ddd;
	font-weight: 500;
	font-size: 20px;
	padding: 5px 0;
	border: 2px solid transparent;
	letter-spacing: 0.5px;
	margin: 10px 15px 0 15px;
}
#prg.navbar-default .navbar-nav > li > a:hover {
	color: <?php echo $maincolor1; ?>;
}
.on {
	background-color: #262626 !important;
	padding: 0 !important;
	padding: 10px 0 !important;
}
.navbar-default .navbar-nav > .active > a, .navbar-default .navbar-nav > .active > a:hover, .navbar-default .navbar-nav > .active > a:focus {
	color: <?php echo $maincolor1; ?> !important;
	background-color: transparent;
}
.navbar-toggle {
	border-radius: 0;
}
.navbar-default .navbar-toggle:hover, .navbar-default .navbar-toggle:focus {
	background-color: <?php echo $maincolor1; ?>;
	border-color: <?php echo $maincolor1; ?>;
}
.navbar-default .navbar-toggle:hover>.icon-bar {
	background-color: #FFF;
}
.section-title {
	margin-bottom: 70px;
	background: url('../img/intro-bg-RVB-2.png') no-repeat center center fixed;
	background-size: cover;
}
.section-title h2, .section-title p {
	color: white;
 text-shadow:-1px -1px 9px #000;
}

.section-title .overlay {
	padding: 80px 0;

}
.section-title p {
	font-size: 22px;
	color: rgba(255,255,255,0.8);
}
.section-title hr {
	margin: 0 auto;
	margin-bottom: 40px;
}
.btn-custom {
	text-transform: uppercase;
	color: #fff;
	background-color: <?php echo $maincolor1; ?>;
	border: 0;
	padding: 14px 20px;
	margin: 0;
	font-size: 16px;
	font-weight: 500;
	letter-spacing: 0.5px;
	border-radius: 0;
	margin-top: 20px;
	transition: all 0.5s;
}
.btn-custom:hover, .btn-custom:focus, .btn-custom.focus, .btn-custom:active, .btn-custom.active {
	color: #fff;
	background-color: <?php echo $hover_maincolor1; ?>;
}
/* Header Section */
.intro {
	display: table;
	width: 100%;
	padding: 0;
	background: url(../img/intro-bg-RVB-2.png) no-repeat center center fixed;
	background-color: #e5e5e5;
	-webkit-background-size: cover;
	-moz-background-size: cover;
	background-size: cover;
	-o-background-size: cover;
}
.intro .overlay {
	background: rgba(0,0,0,0.2);
}
.intro h1 {
	font-family: 'CaslonCP', cursive;
	text-transform: uppercase;
	text-shadow:-1px -1px 9px #000;
	color: #fff;
	font-size: 6em;
	font-weight: 400;
	margin-top: 0;
	margin-bottom: 10px;
}
.intro h2 {
	font-family: 'CaslonCP', cursive;
	text-transform: uppercase;
	text-shadow:-1px -1px 9px #000;
	color: #fff;
	font-size: 3em;
	font-weight: 200;
	margin-top: 0;
	margin-bottom: 10px;
}
.intro span {
	color: #a7c44c;
	font-weight: 600;
}
.intro p {
	color: #fff;
	text-shadow:-1px -1px 9px #000;
	font-size: 34px;
	font-weight: 400;
	margin-top: 10px;
	margin-bottom: 40px;
}
header .intro-text {
	padding-top: 250px;
	padding-bottom: 200px;
	text-align: center;
}
/* About Section */
#about {
	padding: 120px 0;
}
#about h3 {
	font-size: 20px;
}
#about .about-text {
	margin-left: 10px;
}
#about .about-img {
	display: inline-block;
	position: relative;
}
#about .about-img:before {
	display: block;
	content: '';
	position: absolute;
	top: 8px;
	right: 8px;
	bottom: 8px;
	left: 8px;
	border: 1px solid rgba(255, 255, 255, 0.5);
}
#about p {
	line-height: 24px;
	margin: 15px 0 30px;
}

ul.cat li {
	display: inline-block;
}
ol.type li {
	display: inline-block;
	margin: 0 10px;
	padding: 20px 0;
}
ol.type li a {
	color: #999;
	font-weight: 500;
	font-size: 14px;
	padding: 12px 24px;
	background: #eee;
	border: 0;
	border-radius: 0;
	text-transform: uppercase;
	letter-spacing: 0.5px;
}
ol.type li a.active {
	color: #fff;
	background-color: <?php echo $maincolor1; ?>;
}
ol.type li a:hover {
	color: #fff;
	background-color: <?php echo $maincolor1; ?>;
}
.isotope-item {
	z-index: 2
}
.isotope-hidden.isotope-item {
	z-index: 1
}
.isotope, .isotope .isotope-item {
	/* change duration value to whatever you like */
	-webkit-transition-duration: 0.8s;
	-moz-transition-duration: 0.8s;
	transition-duration: 0.8s;
}
.isotope-item {
	margin-right: -1px;
	-webkit-backface-visibility: hidden;
	backface-visibility: hidden;
}
.isotope {
	-webkit-backface-visibility: hidden;
	backface-visibility: hidden;
	-webkit-transition-property: height, width;
	-moz-transition-property: height, width;
	transition-property: height, width;
}
.isotope .isotope-item {
	-webkit-backface-visibility: hidden;
	backface-visibility: hidden;
	-webkit-transition-property: -webkit-transform, opacity;
	-moz-transition-property: -moz-transform, opacity;
	transition-property: transform, opacity;
}
.portfolio-item {
	margin: 15px 0;
}
.portfolio-item .hover-bg {
	overflow: hidden;
	position: relative;
}
.portfolio-item .hover-bg:before {
	display: block;
	content: '';
	position: absolute;
	top: 6px;
	right: 6px;
	bottom: 6px;
	left: 6px;
	border: 1px solid rgba(255, 255, 255, 0.6);
}
.hover-bg .hover-text {
	position: absolute;
	text-align: center;
	margin: 0 auto;
	color: #fff;
	background: rgba(38, 22, 84, 0.3);
	padding: 30% 0 0 0;
	height: 100%;
	width: 100%;
	opacity: 0;
	transition: all 0.5s;
}
.hover-bg .hover-text>h4 {
	opacity: 0;
	color: #fff;
	-webkit-transform: translateY(100%);
	transform: translateY(100%);
	transition: all 0.3s;
	font-size: 17px;
	letter-spacing: 0.5px;
	font-weight: 500;
}
.hover-bg:hover .hover-text>h4 {
	opacity: 1;
	-webkit-backface-visibility: hidden;
	-webkit-transform: translateY(0);
	transform: translateY(0);
}
.hover-bg:hover .hover-text {
	opacity: 1;
}

/* Contact Section */
#contact {
	padding: 100px 0 60px 0;
	background: #F6F6F6;
}

#contact form {
	padding: 0;
}
#contact h3 {
	text-transform: uppercase;
	font-size: 20px;
	font-weight: 400;
	color: #555;
}
#contact .text-danger {
	color: #cc0033;
	text-align: left;
}
label {
	font-size: 12px;
	font-weight: 400;
	font-family: 'Open Sans', sans-serif;
	float: left;
}
#contact .form-control {
	display: block;
	width: 100%;
	padding: 6px 12px;
	font-size: 16px;
	line-height: 1.42857143;
	color: #444;
	background-color: #fff;
	background-image: none;
	border: 1px solid #ddd;
	border-radius: 0;
	-webkit-box-shadow: none;
	box-shadow: none;
	-webkit-transition: none;
	-o-transition: none;
	transition: none;
}
#contact .form-control:focus {
	border-color: #999;
	outline: 0;
	-webkit-box-shadow: transparent;
	box-shadow: transparent;
}
.form-control::-webkit-input-placeholder {
color: #000;
}
.form-control:-moz-placeholder {
color: #000;
}
.form-control::-moz-placeholder {
color: #000;
}
.form-control:-ms-input-placeholder {
color: #000;
}
#contact .contact-item {
	margin: 20px 0 40px 0;
}
#contact .contact-item span {
	font-weight: 400;
	color: #aaa;
	text-transform: uppercase;
	margin-bottom: 6px;
	display: inline-block;
}
#contact .contact-item p {
	font-size: 16px;
}
/* Footer Section*/
#footer {
	background: <?php echo $maincolor2; ?>;
	padding: 50px 0 0 0;
}
#footer h3 {
	color: <?php echo $maincolor1; ?>;
	font-weight: 400;
	font-size: 18px;
	text-transform: uppercase;
	margin-bottom: 20px;
}
#footer .copyrights {
	padding: 20px 0;
	margin-top: 50px;
	/* Permalink - use to edit and share this gradient: http://colorzilla.com/gradient-editor/#779936+0,E72A7B+50 */
	background: <?php echo $maincolor1; ?> ; /* Old browsers */
	background: -moz-linear-gradient(top, <?php echo $maincolor2; ?> 0%, <?php echo $maincolor1; ?> 50%); /* FF3.6-15 */
	background: -webkit-linear-gradient(top, <?php echo $maincolor2; ?> 0%, <?php echo $maincolor1; ?> 50%); /* Chrome10-25,Safari5.1-6 */
	background: linear-gradient(to bottom, <?php echo $maincolor2; ?> 0%, <?php echo $maincolor1; ?> 50%); /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#779936', endColorstr='<?php echo $maincolor1; ?>', GradientType=0 ); /* IE6-9 */
}
#footer .social i.fa {
	font-size: 26px;
	padding: 20px;
	color: #fff;
	transition: all 0.3s;
}
#footer .social i.fa:hover {
	color: <?php echo $maincolor2; ?>;
}
#footer p {
	font-size: 15px;
	color: rgba(255,255,255,0.8)
}
#footer a {
	color: #f6f6f6;
}
#footer a:hover {
	color: #333;
}

.color-it {
  color: <?php echo $maincolor1; ?>
}
