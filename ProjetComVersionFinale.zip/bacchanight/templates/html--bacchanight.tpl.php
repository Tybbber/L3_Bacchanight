<?php
include 'content/config.php';
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $titre; ?></title>
    <meta name="description" content="">
    <meta name="author" content="Université de Bordeaux">

    <!-- Favicons
    ================================================== -->
    <link rel="shortcut icon" href="sites/all/modules/bacchanight/templates/img/favicon.ico" type="image/x-icon">
    <link rel="apple-touch-icon" href="sites/all/modules/bacchanight/templates/img/apple-touch-icon.png">
    <link rel="apple-touch-icon" sizes="72x72" href="sites/all/modules/bacchanight/templates/img/apple-touch-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="114x114" href="sites/all/modules/bacchanight/templates/img/apple-touch-icon-114x114.png">

    <!-- Bootstrap -->
    <link rel="stylesheet" type="text/css"  href="sites/all/modules/bacchanight/templates/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="sites/all/modules/bacchanight/templates/fonts/font-awesome/css/font-awesome.css">

    <!-- Stylesheet
    ================================================== -->
    <link rel="stylesheet" type="text/css"  href="sites/all/modules/bacchanight/templates/css/style.php">
    <link rel="stylesheet" type="text/css" href="sites/all/modules/bacchanight/templates/css/nivo-lightbox/nivo-lightbox.css">
    <link rel="stylesheet" type="text/css" href="sites/all/modules/bacchanight/templates/css/nivo-lightbox/default.css">
    <link href="https://fonts.googleapis.com/css?family=Raleway:300,400,500,600,700" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Dancing+Script:400,700" rel="stylesheet">
    <script src='https://www.google.com/recaptcha/api.js'></script>
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style>#page-wrapper {display: none;}</style>
    <?php echo $colorStyle; ?>
</head>
<body id="page-top" data-spy="scroll" data-target=".navbar-fixed-top">
    <!-- Navigation
    ==========================================-->
    <nav id="prg" class="navbar navbar-default navbar-fixed-top">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
                <a class="navbar-brand page-scroll" href="#page-top">Bacchanight</a> </div>

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="#about" class="page-scroll">&Agrave; Propos</a></li>
                        <li><a href="#programme" class="page-scroll">Programme</a></li>
                        <li><a href="#gallery" class="page-scroll">Galerie des photos</a></li>
                        <li><a href="#contact" class="page-scroll">Contact</a></li>
                        <li><a href="#partners" class="page-scroll">Partenaires</a></li>
                    </ul>
                </div>
                <!-- /.navbar-collapse -->
            </div>
        </nav>
        <!-- Header -->
        <header id="header">
            <div class="intro" id="intro">
                <div class="overlay">
                    <div class="container">
                        <div class="row">
                            <div class="intro-text">
                                <div class="hidden-xs hidden-sm">
                                    <h1>Bacchanight</h1>
                                    <p>Musée des Beaux Arts - Bordeaux</p>
                                    <a target="_blank" href="sites/all/modules/bacchanight/templates/img/affiche.pdf" class="btn btn-custom btn-lg page-scroll">Découvrez Bacchanight!</a>
                                </div>
                                <div class="hidden-md hidden-lg">
                                    <h2>Bacchanight</h2>
                                    <p>Musée des Beaux Arts - Bordeaux</p>
                                    <a target="_blank" href="sites/all/modules/bacchanight/templates/img/affiche.pdf" class="btn btn-custom btn-lg page-scroll">Découvrez Bacchanight!</a>
                                </div>
                                <!--<script type="text/javascript">
                                function StopGray() {
                                document.getElementById("intro").className = "intro";
                            }
                            function StartGray() {
                            document.getElementById("intro").className += " gray-img";
                        }
                    </script>-->
                </div>
            </div>
        </div>
    </div>
</div>
</header>
<!-- About Section -->
<div id="about">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 col-md-6 ">
                <div class="about-img gray-img"><img src="sites/all/modules/bacchanight/templates/img/about.jpg" class="img-responsive" alt="About"></div>
            </div>
            <div class="col-sm-12 col-md-6">
                <div class="about-text">
                    <?php echo $description ?>
                </div>
            </div>
        </div>
    </div>
</div>

<div id="programme">
    <div class="section-title text-center center">
        <div class="overlay">
            <h2>Programme de la Bacchanight</h2>
            <hr>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <?php

            $prg=simplexml_load_string($programme) or die("Error: Cannot create object");

            ?>


            <div class="col-xs-12 col-sm-6">
                <div class="prg-section">
                    <h2 class="prg-section-title">Programme</h2>
                    <hr>
                    <br><p class="color-it">
                        <strong>[G= Galerie]  [M= musée]</strong>
                    </p><br>
                    <?php foreach ($prg->programme[0]->event as $event): ?>
                        <div class="prg-item">
                            <div class="prg-item-description">
                                <h3><?php echo $event->titre ?></h3>
                                <p>
                                    <?php echo $event->description ?>
                                    <?php if ($event->location == "M" || $event->location == "G"): ?>
                                        <strong class="color-it">[<?php echo $event->location ?>]</strong>
                                    <?php endif; ?>
                                </p>
                            </div>
                        </div>
                    <?php endforeach;?>

                </div>
            </div>

            <div class="col-xs-12 col-sm-6">
                <div class="about-img gray-img"><img src="sites/all/modules/bacchanight/templates/img/Plan.png" class="img-responsive" alt="Plan"></div>
                <div class="prg-section">
                    <h2 class="prg-section-title">En continu </h2><hr>
                    <?php foreach ($prg->programme[1]->event as $event): ?>
                        <div class="prg-item">
                            <div class="prg-item-description">
                                <h3><?php echo $event->titre ?></h3>
                                <p>
                                    <?php echo $event->description ?>
                                    <?php if ($event->location == "M" || $event->location == "G"): ?>
                                        <strong class="color-it">[<?php echo $event->location ?>]</strong>
                                    <?php endif; ?>
                                </p>
                            </div>
                        </div>
                    <?php endforeach;?>

                </div>
            </div>
        </div>
    </div>


    <div id="gallery" style="margin-top:50px;">
        <div class="section-title text-center center">
            <div class="overlay">
                <h2>Galerie des photos</h2>
                <hr>
            </div>
        </div>
        <div class="container">
            <?php
            $dir = "sites/all/modules/bacchanight/templates/img/gallery/large/";
            $images = glob($dir."*.{jpg,png,gif}", GLOB_BRACE);
            ?>
            <?php foreach ($images as $img): ?>
                <div class="col-sm-6 col-md-4 col-lg-4 breakfast">
                    <div class="portfolio-item">
                        <div class="hover-bg"> <a href="<?php echo $img ?>" title="Bacchanight" target="_blank" data-lightbox-gallery="gallery1">
                            <div class="hover-text">

                            </div>
                            <img src="<?php echo $img ?>" class="img-responsive" alt="Bacchanight"> </a> </div>
                        </div>
                    </div>
                <?php endforeach; ?>
                <br><br>
            </div>
        </div>
    </div>

        <div id="contact" class="text-center">
            <div class="section-title text-center center">
                <div class="overlay">
                    <h2>Contact</h2>
                    <hr>
                </div>
            </div>
            <div class="container">
                <div class="col-md-10 col-md-offset-1">
                    <form name="sentMessage" id="contactForm" action=""  novalidate>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <input type="text" id="name" name="name" class="form-control" placeholder="Nom" required="required">
                                    <p class="help-block text-danger"></p>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <input type="email" name="email" id="email" class="form-control" placeholder="Email" required="required">
                                    <p class="help-block text-danger"></p>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <textarea name="message" id="message" class="form-control" rows="4" placeholder="Message" required></textarea>
                            <p class="help-block text-danger"></p>
                        </div>
                        <div id="success"></div>
                        <div class="g-recaptcha" data-sitekey="<?php echo $captcha; ?>"></div>
                        <button type="submit" class="btn btn-custom btn-lg">Envoyer</button>
                        <br>
                    </form>
                </div>
            </div>
        </div>



        <div class="section-title text-center center" id="partners">
            <div class="overlay">
                <h2>
                    <strong>Merci à tous nos partenaires !</strong>
                </h2>
                <hr>
            </div>
        </div>
        <div class="container">
            <div class="col-sm-12">
                <div class="container">
                    <center>

                        <!--
                        <img src="sites/all/modules/bacchanight/templates/img/partners/1.png" alt="Artothem" width="150px"/>
                        <img src="sites/all/modules/bacchanight/templates/img/partners/2.png" alt="Bordeaux Broken Consort" width="150px"/>
                        <img src="sites/all/modules/bacchanight/templates/img/partners/3.png" alt="ECRAN LISAA" width="150px"/>
                        <img src="sites/all/modules/bacchanight/templates/img/partners/4.png" alt="Université Bordeaux Montaigne" width="150px"/>
                        <img src="sites/all/modules/bacchanight/templates/img/partners/6.png" alt="CIVB Bordeaux" width="150px"/><br/>
                        <img src="sites/all/modules/bacchanight/templates/img/partners/7.png" alt="Chateau Haut-Bailly" width="150px"/>
                        <img src="sites/all/modules/bacchanight/templates/img/partners/8.png" alt="Cultiv'actions" width="150px"/>
                        <img src="sites/all/modules/bacchanight/templates/img/partners/9.png" alt="IBSM" width="150px"/>
                        <img src="sites/all/modules/bacchanight/templates/img/partners/10.png" alt="ICART" width="150px"/>
                        <img src="sites/all/modules/bacchanight/templates/img/partners/12.png" alt="CDFA/CFPPA" width="150px"/>
                        <br/>
                        <img src="sites/all/modules/bacchanight/templates/img/partners/14.png" alt="Radio Campus Bordeaux" width="150px"/>
                        <img src="sites/all/modules/bacchanight/templates/img/partners/15.png" alt="Université de Bordeaux" width="150px"/>
                        <img src="sites/all/modules/bacchanight/templates/img/partners/16.png" alt="ESTBA" width="150px"/>-->
                        <p>CIVB, Radiocampus, IBSM, CFPPA du lycée agricole de Blanquefort, ICART, Conservatoire de Bordeaux, Université de Bordeaux Montaigne, Université de Bordeaux, ESTBA, ECRAN LISAA, l’association Artothem et l’association Cultiv’actions
                        </p>
                        <br/>
                        <br/>
                        <img src="sites/all/modules/bacchanight/templates/img/HautBailly.jpg" alt="Chateau Haut-Bailly" width="300px"/>
                        <p>Château Haut-Bailly</p><br/>
                        <br/>	</center>
                    </div>
                </div>
            </div>
            <div id="footer">
                <div class="container text-center">
                    <div class="col-md-4">
                        <h3>Adresse</h3>
                        <div class="contact-item">
                            <?php echo $address."<br/>"; ?>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <h3>Date et heure</h3>
                        <div class="contact-item">
                            <p>
                                <?php echo $date."<br/>".$heure; ?>
                            </p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <h3>informations de Contact</h3>
                        <div class="contact-item">
                            <p>Téléphone: <?php echo $phone; ?></p>
                            <p>Email: <?php echo $email; ?></p>
                        </div>
                    </div>
                </div>
                <div class="container-fluid text-center copyrights">
                    <div class="col-md-12">
                        <div class="social">
                            <a href="http://www.facebook.com/bordeaux.musee.ba"><i class="fa fa-facebook"></i></a>
                            <a href="https://twitter.com/mbabx"><i class="fa fa-twitter"></i></a>
                            <a href="https://www.instagram.com/mba_bordeaux/"><i class="fa fa-instagram"></i></a>
                        </div>
                        <p>
                            <img src="sites/all/modules/bacchanight/templates/img/partners/mairie.png" alt="Mairie de Bordeaux" width="100px"/>
                            <img src="sites/all/modules/bacchanight/templates/img/partners/mba.png" alt="Musée des Beaux Arts de Bordeaux" width="100px"/>
                        </p>      <p>&copy; 2017 Bacchanight. All rights reserved. Photo &copy; : Frédéric Deval</p>
                    </div>
                </div>
            </div>
            <script src="http://code.jquery.com/jquery-2.1.1.min.js"></script>
            <script type="text/javascript" src="sites/all/modules/bacchanight/templates/js/bootstrap.js"></script>
            <!--<script type="text/javascript" src="sites/all/modules/bacchanight/templates/js/SmoothScroll.js"></script>-->
            <script type="text/javascript" src="sites/all/modules/bacchanight/templates/js/nivo-lightbox.js"></script>
            <script type="text/javascript" src="sites/all/modules/bacchanight/templates/js/jquery.isotope.js"></script>
            <script type="text/javascript" src="sites/all/modules/bacchanight/templates/js/jqBootstrapValidation.js"></script>
            <script type="text/javascript" src="sites/all/modules/bacchanight/templates/js/contact_me.js"></script>
            <script type="text/javascript" src="sites/all/modules/bacchanight/templates/js/main.js"></script>
            <script>
            (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
                (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
                m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
            })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

            ga('create', 'UA-93669230-1', 'auto');
            ga('send', 'pageview');

            </script>
        </body>
        </html>
        <?php die(); ?>
