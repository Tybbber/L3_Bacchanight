<?php

$titre = "Bacchatitre";
$email = "Bacchamail@baccha.mail";
$phone = "3";
$street = "Baccarue";
$zipcode = "00000";
$city = "Orthez";
$country = "France";
$date = "MARDI 21 MARS 2017";
$address = "<p>".$street."<br>".$zipcode." ".$city.", ".$country."</p>";
$heure = "20h - 00h";
$color1 = "#000000";
$color2 = "#000000";
$captcha = "6Le8yB4UAAAAABTVJGnHAyTuU7Ej7uwFPGKAF2pv";
$programme = "<?xml version='1.0' standalone='yes'?>
<ListeProgramme>
<programme>
<event>
<location>M</location>
<titre>10h10 comme le volant</titre>
<description>La soirée de votre vie</description>
</event>
<event>
<location>M</location>
<titre>6h45 l'heure du ricard</titre>
<description>La deuxième meilleure soirée de votre vie</description>
</event>
</programme>
<programme>
<event>
<location>M</location>
<titre>10h15 comme le volant</titre>
<description>La soirée de votre vie</description>
</event>
<event>
<location>M</location>
<titre>6h45 l'heure du ricard</titre>
<description>La deuxième meilleure soirée de votre vie</description>
</event>
</programme>
</ListeProgramme>";

?>
