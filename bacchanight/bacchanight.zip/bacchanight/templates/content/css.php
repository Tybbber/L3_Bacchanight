<?php
$bgcolor = "#FFF";
$maincolor1 = "#E72A7B";
$hover_maincolor1 = "#cf256e";
$maincolor2 = "#201C54";
?>
