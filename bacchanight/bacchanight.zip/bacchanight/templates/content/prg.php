<?php
    //include 'var.php';

    //echo $programme;
    $xml = <<<XML
	<?xml version='1.0' standalone='yes'?>
    <Test>
        <Hello>Bonjour</Hello>
    </Test>
    XML;
    $test = new SimpleXMLElement($xml);
    var_dump($test);
 ?>



<div class="col-xs-12 col-sm-6">
  <div class="prg-section">
    <h2 class="prg-section-title">Programme</h2>
    <hr>
    <br><p class="color-it">
      <strong>[G= Galerie]  [M= musée]</strong>
    </p><br>
    <?php
    $listprg = new SimpleXMLElement($programme);
    $prg = [$listprg->programme[0], $listprg->programme[1]];
    var_dump($listprg);  ?>
      <?php foreach ($prg[0]->event as $event): ?>
        <div class="prg-item">
          <div class="prg-item-description">
            <h3><?php echo $event->titre ?></h3>
            <p>
              <?php echo $event->description ?>
              <?php if ($event->location == "M" || $event->location == "G"): ?>
                <strong class="color-it">[<?php echo $event->location ?>]</strong>
              <?php endif; ?>
            </p>
          </div>
        </div>
      <?php endforeach; ?>

</div>
</div>

<div class="col-xs-12 col-sm-6">
  <div class="about-img gray-img"><img src="sites/all/modules/bacchanight/templates/img/Plan.png" class="img-responsive" alt="Plan"></div><div class="prg-section">
    <h2 class="prg-section-title">En continu </h2><hr>
    <?php foreach ($prg[1]->event as $event): ?>
      <div class="prg-item">
        <div class="prg-item-description">
          <h3><?php echo $event->titre ?></h3>
          <p>
            <?php echo $event->description ?>
            <?php if ($event->location == "M" || $event->location == "G"): ?>
              <strong class="color-it">[<?php echo $event->location ?>]</strong>
            <?php endif; ?>
          </p>
        </div>
      </div>
    <?php endforeach; ?>

</div>
</div>
