<?php
	$titre = "Bacchanight - Musée des Beaux Arts - Bordeaux";
	$email = "s.choux<i class='fa fa-at'></i>mairie-bordeaux.fr";
	$phone = "+33 5 56 10 20 56";
	$street = ["20 Cours d'Albret","Galerie des Beaux-Arts<br/>Place du Colonel Raynal,"];
	$zipcode = ["33000","33000"];
	$city = ["Bordeaux","Bordeaux"];
	$country = ["France","France"];
	$address = ["<p>".$street[0]."<br>".$zipcode[0]." ".$city[0].", ".$country[0]."</p>","<p>".$street[1]."<br>".$zipcode[1]." ".$city[1].", ".$country[1]."</p>"];
	$date = "MARDI 21 MARS 2017";
	$heure = "20h - 00h";

	// Programme
	$programme = "<?xml version='1.0' standalone='yes'?>
	<ListeProgramme>
	<programme>
	  <event>
			<location>M</location>
	    <titre>20h15 : Défilé de mode</titre>
	    <description>
	      Par les élèves de l’école de mode IBSM, coiffure et maquillage par les élèves de l’école Piger Création
	    </description>
	  </event>
	  <event>
			<location>G</location>
	    <titre>20h15 à 22h30: Visite et dégustation de vins</titre>
	    <description>
	      Visites flash par l’association Artothem, suivie d’une dégustation de vins par Blandine Prevot, Geoffrey Thibaud, Jordi Payot et Adrien Ferraro
	    </description>
	  </event>
	  <event>
			<location>M</location>
	    <titre>20h30 et 22h : Histoire d'amour chantée</titre>
	    <description>
	     Par Laura-Marie Bertinoucourt Leleu, Reine Boukaka Prefina et Ema Donnefort
	    </description>
	  </event>
	  <event>
			<location>M</location>
			<titre>20h30 : Énigmes, enquête dans les collections !</titre>
 		  <description>Par Johanna Michler et Léa Maillard</description>
	  </event>
	  <event>
			<location>G</location>
			<titre>20h30 à 21h30 : Sérigraphie, exposition et atelier</titre>
			<description>Par les étudiants en arts graphiques de l’Université de Bordeaux Montaigne</description>
	  </event>
	  <event>
			<location>G</location>
			<titre>21h : Vente aux enchères fictive dans l’exposition Paysages d’Odilon Redon</titre>
			<description>Par des étudiants d'ICART</description>
	  </event>
	  <event>
			<location>M</location>
			<titre>21h00 et 22h30 : Musiques anciennes en déambulation</titre>
			<description>Par le Bordeaux Broken Consort
			</description>
	  </event>
	  <event>
			<location>M</location>
			<titre>21h et 22h : Dialogue fictif devant le Nu de Marquet</titre>
			<description>Par Léa Nercessian, Lisa Lardon, Bérengère Beney et Lise Delaplace
			</description>
	  </event>
		<event>
			<location>M</location>
			<titre>22h : Énigmes, enquête dans les collections !</titre>
      <description>Par Johanna Michler et Léa Maillard
      </description>
		</event>
		<event>
			<location>G</location>
			<titre>21h30 et 22h30 : Bodega Bay, théâtre</titre>
      <description>Par des étudiants de l'ESTBA</description>
		</event>
		<event>
			<location>M</location>
			<titre>21h30 et 22h30 : Performance dansée</titre>
      <description>Sous la direction de Aurélie Ladkani et Paloma Bernadot
      </description>
		</event>
		<event>
			<location>M</location>
			<titre>23h : Anyside, concert</titre>
      <description></description>
		</event>
	</programme>
	<programme>
		<event>
			<location>G</location>
			<titre>A partir de 20h30 : Photobooth, prenez la pause !</titre>
			<description>
					Par Lisa Alcindor, Angélique Salomon et Jules Cier
				</description>
		</event>
		<event>
      <location></location><titre>
      Radiocampus, émission en direct dans le jardin de la Mairie
    </titre>
  </event>
    <event>
      <location>M</location>
    <titre>Photographie, présentation en regard de l’oeuvre Rolla de Gervex</titre>
    <description>
      Par Mathieu Peters, Felix Delamare et Théo Djilene Bores
    </description>
    </event>
    <event>
      <location>M</location>
    <titre>Photographie, le tatouage à travers l’œuvre Saint Sébastien soigné par Sainte Irène du Maitre à la Chandelle</titre>
    <description>
      Par Emma Juillet et Nicolas Jouhet
    </description>
    </event>
    <event>
      <location>G</location>
    <titre>Robes, exposition de 2 robes inspirées des tableaux d'Odilon Redon</titre>
    <description>
      Par Cannelle Augustin, Déborah Mellet, Jennifer Bradley et Alexandrine Soupama
    </description>
    </event>
    <event>
      <location>M</location>
    <titre>Déambulation, étudiants maquillés aux couleurs des tableaux modernes</titre>
    <description>
      Par Camille Roignat et Malika Brizard
    </description>
    </event>
    <event>
      <location>G</location>
    <titre>
      Exposition, présentation de 3 peintures de Jules Cier
    </titre>
    </event>
    <event>
      <location>M</location>
    <titre>À l'ombre du reflet, œuvre collective</titre>
    <description>Par les étudiants du CFPPA du lycée agricole de Blanquefort, exposée entrée sud du musée
    </description>
    </event>
	</programme>
</ListeProgramme>";
?>
