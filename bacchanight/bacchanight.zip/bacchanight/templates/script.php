<div id="programme">
  <div class="section-title text-center center">
    <div class="overlay">
      <?php
      $listprg = new SimpleXMLElement($programme);
      $prg = [$listprg->programme[0], $listprg->programme[1]]  ?>
      <h2>Programme de la Bacchanight</h2>
      <hr>
    </div>
  </div>
  <div class="container">
    <div class="row">
      <div class="col-xs-12 col-sm-6">
        <div class="prg-section">
          <h2 class="prg-section-title">Programme</h2>
          <hr>
          <br><p class="color-it">
            <strong>[G= Galerie]  [M= musée]</strong>
          </p><br>
            <?php foreach ($prg[0]->event as $event): ?>
              <div class="prg-item">
                <div class="prg-item-description">
                  <h3><?php echo $event->titre ?></h3>
                  <p>
                    <?php echo $event->description ?>
                    <?php if ($event->location == "M" || $event->location == "G"): ?>
                      <strong class="color-it">[<?php echo $event->location ?>]</strong>
                    <?php endif; ?>
                  </p>
                </div>
              </div>
            <?php endforeach; ?>

    </div>
  </div>
  <div class="col-xs-12 col-sm-6">
    <div class="about-img gray-img"><img src="sites/all/modules/bacchanight/templates/img/Plan.png" class="img-responsive" alt="Plan"></div><div class="prg-section">
      <h2 class="prg-section-title">En continu </h2><hr>
      <?php foreach ($prg[1]->event as $event): ?>
        <div class="prg-item">
          <div class="prg-item-description">
            <h3><?php echo $event->titre ?></h3>
            <p>
              <?php echo $event->description ?>
              <?php if ($event->location == "M" || $event->location == "G"): ?>
                <strong class="color-it">[<?php echo $event->location ?>]</strong>
              <?php endif; ?>
            </p>
          </div>
        </div>
      <?php endforeach; ?>

  </div>
 </div>
</div>
</div>

<div id="gallery" style="margin-top:50px;">
  <div class="section-title text-center center">
    <div class="overlay">
      <h2>Galerie des photos</h2>
      <hr>
    </div>
  </div>
  <div class="container">
    <?php
      $dir = "sites/all/modules/bacchanight/templates/img/gallery/large/";
      $images = glob($dir."*.jpg");
    ?>
    <?php foreach ($images as $img): ?>
      <div class="col-sm-6 col-md-4 col-lg-4 breakfast">
        <div class="portfolio-item">
          <div class="hover-bg"> <a href="<?php echo $img ?>" title="Bacchanight" target="_blank" data-lightbox-gallery="gallery1">
            <div class="hover-text">

            </div>
            <img src="<?php echo str_replace("large","small",$img) ?>" class="img-responsive" alt="Bacchanight"> </a> </div>
        </div>
      </div>
    <?php endforeach; ?>
      <br><br>
    </div>
  </div>
</div>
